class mail_conf:
    MAIL_SERVER = 'smtp-mail.outlook.com'
    MAIL_PORT =  587
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = 'anonymousanwitashobhit@outlook.com'
    MAIL_PASSWORD = 'Anonymous22'
